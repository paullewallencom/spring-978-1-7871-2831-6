package org.packt.dissect.mvc.model.form;

public class DepartmentForm {
	
	private Integer deptId;
	private String name;
	
	public Integer getDeptId() {
		return deptId;
	}
	public void setDeptId(Integer deptId) {
		this.deptId = deptId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
}
