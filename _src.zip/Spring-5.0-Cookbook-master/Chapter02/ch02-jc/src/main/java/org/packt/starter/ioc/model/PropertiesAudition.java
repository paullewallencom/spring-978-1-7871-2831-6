package org.packt.starter.ioc.model;

import java.util.Properties;

public class PropertiesAudition {
	private Properties auditionAddress;
	private Properties auditionRequirement;

	public Properties getAuditionAddress() {
		return auditionAddress;
	}

	public void setAuditionAddress(Properties auditionAddress) {
		this.auditionAddress = auditionAddress;
	}

	public Properties getAuditionRequirement() {
		return auditionRequirement;
	}

	public void setAuditionRequirement(Properties auditonRequirement) {
		this.auditionRequirement = auditonRequirement;
	}
	
	
	
	

}
