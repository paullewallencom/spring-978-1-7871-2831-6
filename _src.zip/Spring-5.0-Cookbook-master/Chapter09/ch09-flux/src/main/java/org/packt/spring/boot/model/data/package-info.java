/**
 * 
 */
/**
 * @author sjctrags
 *
 */
package org.packt.spring.boot.model.data;