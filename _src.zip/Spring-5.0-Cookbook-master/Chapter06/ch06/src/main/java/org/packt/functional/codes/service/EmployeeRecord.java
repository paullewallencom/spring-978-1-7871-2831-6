package org.packt.functional.codes.service;

import org.packt.functional.codes.model.data.Employee;


public interface EmployeeRecord {
   public Employee getServiceRecord(Integer empid);
}
