package org.packt.functional.codes.service;

public interface Sample {
	
    default void hello(){
		
	}
    
    static void hello2(){
    	
    }

}
