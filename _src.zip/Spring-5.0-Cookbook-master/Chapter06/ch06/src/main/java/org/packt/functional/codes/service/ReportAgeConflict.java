package org.packt.functional.codes.service;

@FunctionalInterface
public interface ReportAgeConflict {

	public void showNotQualified();
}
